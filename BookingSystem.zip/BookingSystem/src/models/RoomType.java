package models;

public class RoomType {
    private int typeID;
    private String typeName;
    private String description;
    private double pricePerNight;

    public RoomType(int typeID, String typeName, String description, double pricePerNight) {
        this.typeID = typeID;
        this.typeName = typeName;
        this.description = description;
        this.pricePerNight = pricePerNight;
    }

    // Getters
    public int getTypeID() { return typeID; }
    public String getTypeName() { return typeName; }
    public String getDescription() { return description; }
    public double getPricePerNight() { return pricePerNight; }
}
