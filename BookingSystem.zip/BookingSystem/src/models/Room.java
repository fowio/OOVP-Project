package models;

public class Room {
    private int roomID;
    private String roomNumber;
    private int typeID;
    private int floor;
    private boolean isAvailable;

    public Room(int roomID, String roomNumber, int typeID, int floor, boolean isAvailable) {
        this.roomID = roomID;
        this.roomNumber = roomNumber;
        this.typeID = typeID;
        this.floor = floor;
        this.isAvailable = isAvailable;
    }

    // Getters here...
}
